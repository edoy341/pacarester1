# HaxShot
Hacking All sosmed metode brutefoce

apt update && apt upgrade

apt install git

git clone https://github.com/muhammadfathul/HaxShot

cd HaxShot

chmod +x *

chmod -R 775 lib

sh install.sh

sh haxshot.sh
